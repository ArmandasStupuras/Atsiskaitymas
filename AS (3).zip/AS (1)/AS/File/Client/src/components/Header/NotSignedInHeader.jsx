import { NavLink } from 'react-router-dom';
import Button from '../Button';

const setActive = ({ isActive }) =>
  isActive ? 'text-btn' : 'text-body-medium hover:text-btn hover:underline';

const NotSignedInHeader = () => {
  return (
    <header className="sticky h-[4rem] bg-[#FFFFFF] shadow-md flex z-50">
      <nav className="flex justify-between self-center items-center w-[100%] px-6">
        <NavLink tabIndex={-1} to={'/'}>
          <section className="flex items-center gap-[1rem]">
          </section>
        </NavLink>
        <section className="h-[1.5rem] w-[23rem] p-1">
          <section className="flex justify-evenly text-body-m not-italic font-[400] leading-4 items-center">
            <NavLink to="/" className={setActive}>
              <h1 className="hover:underline hover">Home</h1>
            </NavLink>
            <NavLink to="/events" className={setActive}>
              <h1 className="hover:underline">Events</h1>
            </NavLink>
            <NavLink to="/about" className={setActive}>
              <h1 className="hover:underline ">About Us</h1>
            </NavLink>
          </section>
        </section>
        <div className="flex items-center gap-4">
          <NavLink tabIndex={-1} to={'/login'}>
            <Button>Login</Button>
          </NavLink>
          <NavLink tabIndex={-1} to={'/register'}>
            <Button>Sign Up</Button>
          </NavLink>
        </div>
      </nav>
    </header>
  );
};

export default NotSignedInHeader;

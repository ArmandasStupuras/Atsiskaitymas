import { Outlet } from 'react-router-dom';
import Header from './Header/Header';
import Footer from './Footer';
import ErrorServer from './message/ErrorServer';
import Success from './message/Success';

const MainLayout = () => {
  return (
    <>
      <ErrorServer />
      <Success />
      <div className="min-h-screen flex flex-col bg-gradient-to-b from-light-yellow via-light-yellow to-cream">
        <Header />
        <main className="flex-1">
          <Outlet />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default MainLayout;
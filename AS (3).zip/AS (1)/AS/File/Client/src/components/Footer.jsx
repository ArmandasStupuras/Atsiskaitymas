const Footer =() => {

    return(
        <section className="h-16 flex justify-center items-center text-light text-body-s border border-input-light bg-white ">
            <h1>© 2025 Eventify. All rights reserved.</h1>
        </section>
    )
}
export default Footer;

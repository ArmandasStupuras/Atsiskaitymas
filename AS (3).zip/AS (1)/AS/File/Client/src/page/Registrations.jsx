const Registrations = () => {

    return(
        <div>
            <h1 className=" font-bold">My Registration page</h1>
        </div>
    )
}
export default Registrations;
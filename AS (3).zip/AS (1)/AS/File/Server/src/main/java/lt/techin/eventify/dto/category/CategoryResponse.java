package lt.techin.eventify.dto.category;

public record CategoryResponse(long id, String name) {
}

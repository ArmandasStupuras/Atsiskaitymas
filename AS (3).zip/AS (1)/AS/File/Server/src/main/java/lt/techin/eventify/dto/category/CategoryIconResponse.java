package lt.techin.eventify.dto.category;

public record CategoryIconResponse(
        byte[] data,
        String contentType
){
}

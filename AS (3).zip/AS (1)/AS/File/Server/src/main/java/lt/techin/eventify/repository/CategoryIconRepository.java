package lt.techin.eventify.repository;

import lt.techin.eventify.model.CategoryIcon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryIconRepository extends JpaRepository<CategoryIcon,Long> {
}

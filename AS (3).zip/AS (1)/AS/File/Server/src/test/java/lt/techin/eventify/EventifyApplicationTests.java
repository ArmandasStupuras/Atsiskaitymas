package lt.techin.eventify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
